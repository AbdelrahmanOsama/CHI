
# CHI

This project for the internal use for CHI employees, made using Tailwind.


## Installation

Install CHI with npm

```bash
  npm install
  cd CHI
```

## How to Run for Development
 
 ```bash
  npm run watch
```